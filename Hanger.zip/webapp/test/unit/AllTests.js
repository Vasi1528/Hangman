sap.ui.define([
	"hanger/Hanger/test/unit/controller/Hanger_view.controller"
], function () {
	"use strict";
});