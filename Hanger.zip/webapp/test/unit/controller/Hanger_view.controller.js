/*global QUnit*/

sap.ui.define([
	"hanger/Hanger/controller/Hanger_view.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Hanger_view Controller");

	QUnit.test("I should test the Hanger_view controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});