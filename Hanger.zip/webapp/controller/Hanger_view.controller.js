sap.ui.define(["sap/m/MessageToast", "sap/ui/core/mvc/Controller"], function (MessageToast, Controller) {
	"use strict";
	var Player, Score, IWord;
	var http = "http://";
	var sServiceUrl = http + "aoh-hana2.c.eu-de-2.cloud.sap:8000/sap/opu/odata/SAP/ZHANGMAN2_SRV";
	var Id;
	var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
	var wIndex, rst, lives;
	var str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	return Controller.extend("hanger.Hanger.controller.Hanger_view", {

		onInit: function () {
			for (var i = 0; i < str.length; i++) {
				this.getView().byId(str.charAt(i)).setEnabled(false);
			}
		},
		onStart: function () {
			this.getView().byId("playerInput").setEnabled(false);
			this.getView().byId("ST").setEnabled(false);
			Player = this.getView().byId("playerInput").getValue();

			for (var i = 0; i < str.length; i++) {
				this.getView().byId(str.charAt(i)).setEnabled(true);
			}
			oModel.read("/GameSet?", null, null, false, function (oData2, oResponse) {
					wIndex = Math.floor(Math.random() * oData2.results[0].Wrdcnt) + 1;
				}

			);
			var oDataS = {
				"Player": Player,
				"Cod": "1",
				"Score": Score,
				"Wrdcnt": wIndex
			};

			oModel.create("/GameSet", oDataS, {
					success: function (oData1) {
						//	MessageToast.show(oData1.Id);
						Id = oData1.Id;
						Score = oData1.Score;
						IWord = oData1.Iword;
						lives = 7;
					},
					error: function () {
						//				MessageToast.show("Error!");
					}

				}

			);
			oModel.read("/GameSet(" + Id + ")?", null, null, false, function (oData2, oResponse) {

			});
			this.getView().byId("playerScore").setValue(Score);
			this.getView().byId("WordId").setValue(IWord);
			this.getView().byId("playerLives").setValue(lives);
		},
		onReset: function () {
			this.getView().byId("playerInput").setEnabled(true);
			for (var i = 0; i < str.length; i++) {
				this.getView().byId(str.charAt(i)).setEnabled(false);
				this.getView().byId("ST").setEnabled(true);
			}
			for (var j = 1; j <= 7; j++) {
				this.getView().byId("h" + j).setVisible(false);
			}
		},
		onPress: function (oEvent) {
			var buttonId = oEvent.getParameter("id"),
				oButton = this.getView().byId(buttonId);
			oButton.setEnabled(false);
			var oUpdate = {

				"Cod": buttonId.slice(32)

			};
			oModel.read("/GameSet?", null, null, false, function (oData2, oResponse) {
				wIndex = Math.floor(Math.random() * oData2.results[0].Wrdcnt);
			});

			oModel.update("/GameSet(" + Id + ")?", oUpdate, {
				success: function () {
					oModel.read("/GameSet(" + Id + ")?", null, null, false, function (oData2, oResponse) {
						IWord = oData2.Iword;
						Score = oData2.Score;
						lives = oData2.Lives;
						var oDataS = {
							"Player": Player,
							"Cod": oData2.Cod,
							"Score": Score,
							"Wrdcnt": wIndex,
							"Lives": lives
						};
						if (lives === 0) {
							MessageToast.show("No lives remained\n" + "Your final score is " + Score);
							rst = 2;

						} else
						if (oData2.Iword === oData2.Word) {

							rst = 1;
							oModel.create("/GameSet", oDataS, {
									success: function (oData3) {

										Id = oData3.Id;
										Score = oData3.Score;
										IWord = oData3.Iword;
										lives = oData3.Lives;
									},
									error: function () {
										//				MessageToast.show("Error!");
									}

								}

							);

						}

					});
				},
				error: function () {
					MessageToast.show("Error");
				}

			});
			this.getView().byId("playerScore").setValue(Score);
			this.getView().byId("WordId").setValue(IWord);
			this.getView().byId("playerLives").setValue(lives);
			if (lives < 7)
				{this.getView().byId("h" + (7 - lives)).setVisible(true);}

			if (rst === 1) {
				for (var i = 0; i < str.length; i++) {
					this.getView().byId(str.charAt(i)).setEnabled(true);
				}
				rst = 0;
				for (var j = 1; j <= 7; j++) {
					this.getView().byId("h" + j).setVisible(false);
				}
			}
			if (rst === 2) {
				for (i = 0; i < str.length; i++) {
					this.getView().byId(str.charAt(i)).setEnabled(false);
				}
				rst = 0;
			}

		}
	});
});